
module.exports.main = function (event) {
  console.log('The event is: ', event)
  return `The Event is:${event}`
}


